use football_data;
select * from match_results;
select * from player_stats;

-- Least 10 occupied stadiums by attendance
Select game_id, stadium, attendance from match_Results order by attendance asc limit 10;

-- Checking for null values in attendance column
select * from match_results where attendance is null;

-- Most frequent referee
select referee, count(*) as match_count from match_results group by referee 
order by match_count desc limit 5;

-- Count of total matches held
select count(*) from match_results;

-- Count of matches per home club
select home_club_name, count(*) as total_matches from match_results 
group by home_club_name order by total_matches desc;

-- count of matches per away club
select away_club_name, count(*) as total_matches from match_results 
group by away_club_name order by total_matches desc;

-- **Stadium wise count of games conducted**
select stadium,count(game_id) from match_results group by stadium order by count(game_id) desc limit 5;

-- ** countof matches played per season**
select year(date) as season, count(*) as total_matches from match_results group by season order by season;

-- **games where home_club_goals > away_club_goals**
select game_id, home_club_goals,away_club_goals from match_results where home_club_goals > away_club_goals;

-- **Top 10 matches by goals scored**
select *, (home_club_goals + away_club_goals) as total_goals from match_results 
order by total_goals desc limit 10;

select m.game_id, m.date, m.stadium, p.player_name, p.goals from match_results m 
join player_stats p on m.game_id = p.game_id order by m.date desc limit 10;

select* from player_stats;
select * from match_results;
alter table match_results drop column home_win;

